package com.example.sbcurry.tutorial;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void future(View view){
        goToNewPage("You Got Treasures", FutureActivity.class);
    }
    public void cube(View view){
        goToNewPage("3D Cube", Main3DActivity.class);
    }
    public void blank(View view){
        goToNewPage("Blank", BlankActivity.class);
    }
    private void goToNewPage(String text, Class cls){
//        Toast toast = Toast.makeText(this,text,Toast.LENGTH_LONG);
        Toast toast = Toast.makeText(getApplicationContext(),text,Toast.LENGTH_LONG);
        toast.show();
        Intent intent = new Intent(this,cls);
        startActivity(intent);
    }
}

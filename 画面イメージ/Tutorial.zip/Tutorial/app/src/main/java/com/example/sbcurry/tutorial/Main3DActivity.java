package com.example.sbcurry.tutorial;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Main3DActivity extends AppCompatActivity {

    MyGLView myGLView;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        myGLView = new MyGLView(this);
        setContentView(myGLView);
    }
    public void onResume(){
        super.onResume();
        myGLView.onResume();
    }
    public void onPause(){
        super.onPause();
        myGLView.onPause();
    }

}

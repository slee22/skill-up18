package com.example.sbcurry.tutorial;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.Date;
import java.util.Random;

import static java.lang.Math.sqrt;

public class BlankActivity extends AppCompatActivity {

    int KABI_IMAGE_SIZE_MAX = 100;

    //温度
    int temp=20;
    //湿度
    int humi=50;
    //掃除
    int clean=1;

    int kabiIndex = 50;
    int tempIndex = 0;
    int humiIndex =0;
    int cleanIndex = 0;

    public void setTemp(int t){
        temp = t;
    }

    public void setHumi(int h){
        humi = h;
    }

    public void setClean(int c){
        clean = c;
    }


    public void calcKabiIndex(){

        ImageView imgViewKabiTemp = (ImageView)findViewById(R.id.kabiTemp);
        ImageView imgViewKabiHumi = (ImageView)findViewById(R.id.kabiHumi);
        ImageView imgViewKabiClean = (ImageView)findViewById(R.id.kabiClean);
        TextView textKabiIndex = (TextView)findViewById(R.id.kabiIndex);
        TextView textTemp = (TextView)findViewById(R.id.temp);
        TextView textHumi = (TextView)findViewById(R.id.humi);
        TextView textClean = (TextView)findViewById(R.id.clean);

        //カビ指数(温度) 25度(20-30度の中間)からの温度差を2乗して100から引く。マイナスになったら0に切り上げ
        tempIndex = 100 - (25 - temp)*(25 - temp);
        tempIndex = tempIndex > 0?tempIndex:0;

        //カビ指数(湿度) 0～70→0～100になるよう変換。100以上は100に切り下げ
        humiIndex = humi * 100 / 70;
        humiIndex = humiIndex > 100?100:humiIndex;

        //カビ指数(掃除) 0～24→0～100になるよう変換。100以上は100に切り下げ
        cleanIndex = clean * 100 / 24;
        cleanIndex = cleanIndex > 100?100:cleanIndex;

        //カビ指数(総合)全部かけ合わせて0～100になるよう調整
        kabiIndex = tempIndex * humiIndex * cleanIndex / 100 / 100;

        Log.d("temp       :",String.valueOf(temp));
        Log.d("temp index :",String.valueOf(tempIndex));
        Log.d("humi       :",String.valueOf(humi));
        Log.d("humi index :",String.valueOf(humiIndex));
        Log.d("clean      :",String.valueOf(clean));
        Log.d("clean index:",String.valueOf(cleanIndex));
        Log.d("kabi index :",String.valueOf(kabiIndex));


        //カビ指数の表示を更新
        textKabiIndex.setText(String.valueOf(kabiIndex));
        textTemp.setText(String.valueOf(temp)+"℃("+String.valueOf(tempIndex)+")");
        textHumi.setText(String.valueOf(humi)+"％("+String.valueOf(humiIndex)+")");
        textClean.setText(String.valueOf(clean)+"時間("+String.valueOf(cleanIndex)+")");

        //画像のサイズをカビ指数に合わせて変更
        int size;
        //画像のサイズを更新
        size= KABI_IMAGE_SIZE_MAX * tempIndex / 100;
        resize(imgViewKabiTemp,size,size);
        size= KABI_IMAGE_SIZE_MAX * humiIndex / 100;
        resize(imgViewKabiHumi,size,size);
        size= KABI_IMAGE_SIZE_MAX * cleanIndex / 100;
        resize(imgViewKabiClean,size,size);

    }

    public void addTemp(View view){
        temp = temp + 1;
        calcKabiIndex();
    }
    public void subTemp(View view){
        temp = temp - 1;
        calcKabiIndex();
    }
    public void addHumi(View view){
        humi = humi + 1;
        calcKabiIndex();
    }
    public void subHumi(View view){
        humi = humi - 1;
        calcKabiIndex();
    }
    public void addClean(View view){
        clean = clean + 1;
        calcKabiIndex();
    }
    public void subClean(View view){
        clean = clean - 1;
        calcKabiIndex();
    }


    protected void resize(ImageView iv, int w, int h){
        ViewGroup.LayoutParams params = iv.getLayoutParams();
        params.width = w;
        params.height = h;
        iv.setLayoutParams(params);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_blank);

        calcKabiIndex();

    }
}

package xuzhongwei.gunsecury.profile;

public class GenericBluetoothProfile {

}
